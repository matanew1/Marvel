export interface Card {
  id: number
  name: string
  power: number
  team: "Avengers" | "X-Men" | "Guardians" | "Villains" | "Mystic"
}
